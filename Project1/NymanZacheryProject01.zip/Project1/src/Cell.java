/**Project1
 * @author Zachery Nyman
 * 12 January 2016
 */

public class Cell {
	
	private boolean occupied;
	
	public Cell(boolean occ)
	{
		occupied = occ;
	}
	
	public boolean isOccupied()
	{
		return occupied;
	}
	
	
	
	
	
	

}
