/**
 * Lab13
 * @author Zachery Nyman
 * 23 Feb 2017
 */

public interface MessageEncoder {
	
	public abstract String encode(String plaintext);
	
}
