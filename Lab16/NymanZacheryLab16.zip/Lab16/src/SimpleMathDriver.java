/** Lab16
 * @author Zachery Nyman
 * 07 March 2017
 */

public class SimpleMathDriver {

	public static void main(String[] args) {
		
		SimpleMathWindow smw = new SimpleMathWindow();
		smw.setVisible(true);
		
	}

}
