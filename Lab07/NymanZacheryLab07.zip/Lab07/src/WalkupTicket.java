
public class WalkupTicket extends Ticket {
	
	public WalkupTicket()
	{
		super();
	}
	
	public int getPrice()
	{
		return 50;
	}

}
