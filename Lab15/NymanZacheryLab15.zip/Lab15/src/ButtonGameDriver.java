/**
 * Lab15
 * @author Zachery Nyman
 * 02 March 2017
 */

public class ButtonGameDriver {

	public static void main(String[] args) {
		
		ButtonGame bg = new ButtonGame();
		bg.setVisible(true);

	}

}
