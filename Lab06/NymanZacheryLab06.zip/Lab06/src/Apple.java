
public class Apple extends Fruit {
	
	public Apple()
    {
        
    }
	
	public void makeAppleCider()
	{
		System.out.println("makeAppleCider() in Apple class.");
	}

}
