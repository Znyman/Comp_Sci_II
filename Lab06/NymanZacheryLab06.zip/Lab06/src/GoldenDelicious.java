
public class GoldenDelicious extends Apple {
	
	public GoldenDelicious()
    {
        
    }
	
	public void makeAppleCider()
	{
		System.out.println("makeAppleCider() in GoldenDelicious class.");
	}

}
