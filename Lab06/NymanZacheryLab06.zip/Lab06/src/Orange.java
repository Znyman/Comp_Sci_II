
public class Orange extends Fruit {
	
	public Orange()
    {
        
    }
	
	public void makeOrangeJuice()
	{
		System.out.println("makeOrangeJuice() in Orange class.");
	}

}
