
public class Macintosh extends Apple {
	
	public Macintosh()
    {
        
    }
	
	public void makeAppleCider()
	{
		System.out.println("makeAppleCider() in Macintosh class.");
	}

}
