
public class Fruit {
	
	public Fruit()
    {
        
    }
	

}
