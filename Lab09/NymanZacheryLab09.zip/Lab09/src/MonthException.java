/**
 * Lab09
 * @author Zachery Nyman
 * 9 February 2017
 */

public class MonthException extends Exception {
	
	public MonthException()
	{
		super("MonthException");
	}
	
	public MonthException(String message)
	{
		super(message);
	}

}
