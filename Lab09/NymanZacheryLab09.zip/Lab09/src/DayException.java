/**
 * Lab09
 * @author Zachery Nyman
 * 9 February 2017
 */

public class DayException extends Exception {
	
	public DayException()
	{
		super("DayException");
	}
	
	public DayException(String message)
	{
		super(message);
	}

}
